//
//  Ncicon.h
//  ENGINE
//
//  Created by 烟雨 on 2024/4/1.
//  有尝解决Xcode疑难杂症问题   QQ 151384204
//  Copyright © 2024 烟雨. All yan yu.
//

#include <Foundation/Foundation.h>
#include <mach/mach.h>
#include <mach-o/dyld.h>
#include <mach/mach_traps.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface Ncicon : UIWindow

extern NSString * 游戏公告;


@end

NS_ASSUME_NONNULL_END
